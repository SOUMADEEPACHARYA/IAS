from rpc_client import *

print(foo(23))
print(bar(22, "Ashish"))
print(random_rating())