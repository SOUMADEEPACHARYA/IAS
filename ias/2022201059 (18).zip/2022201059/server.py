from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pyftpdlib.authorizers import DummyAuthorizer
import os, socket
ip= '192.168.142.69'
path ='/Users/soumadeepacharya/IAS3/server'
os.chdir(path)
addr= (ip, 2211)
name=DummyAuthorizer()
name.add_user('user1','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')
name.add_user('user2','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')
name.add_user('user3','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')
name.add_user('user4','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')
name.add_user('user5','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')
name.add_user('user6','1234','/Users/soumadeepacharya/IAS3/server',perm='elradfmw')


handler=FTPHandler
handler.authorizer=name
server=FTPServer(addr,handler)
server.serve_forever()
