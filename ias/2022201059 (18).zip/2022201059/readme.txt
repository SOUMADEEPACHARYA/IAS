You have to Crete a folder 
And give ip of server and port
As user you can use user1,user2,user3
User4,user5
