import ftplib
import os
import webbrowser
import codecs
import threading 
from time import sleep
from threading import Event

def downloadFun(ftp,fpath,user, Files, remoteWorkingDirectory):
    i=0
    Code='989'
    while i<len(Files):
        singfile = Files[i]
        i=i+1
       
        # fpath=os.path.join(fpath, user)
       
        path = os.path.join(fpath,singfile)
        # print(path)
        # print("downloading ....... {0}".format(singfile))
        # print(path,singfile)
        # singfile=os.path.join(user,singfile)
       
        with open(path, "wb") as file:
            Code = ftp.retrbinary("RETR " + singfile, file.write)
        ftp.delete(singfile)
       
    if Code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def uploadfunction(ftp,Path,File, workingDir): 
    code='999'
    with open(Path, "rb") as file:
        code = ftp.storbinary(f"STOR {File}", file, blocksize=1024*1024)
    
    if code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False

def readmess(event,User,Pass,Host,Port,chat):
    m=0
    while True:
        ftp = ftplib.FTP(timeout=3000)
        ftp.connect(Host, Port)
        ftp.login(User, Pass)
        ftp.cwd(User)
        
        
        remotefol = "."
        path=User
        
        # data = ftp.nlst()
            

        # htmlfile=[]
    
        # for i in data:
        #     k=i[0:5]
        #     # print(k)
        #     if k==chat:
        #         htmlfile.append(i)

        # n=len(htmlfile)
        # while(True):
        data = ftp.nlst()
        # print(data)
        
        htmlfile=[]
        caluculu=[]
        for i in data:
            k=i[0:5]
            # print(k)
            if k==chat:
                htmlfile.append(i)
            elif i[0]=='x':
                caluculu.append(i)

        n=len(htmlfile)
        
        if n>0:
            isDownloadSuccess = downloadFun(ftp,path,User,htmlfile,remotefol)
            for i in data:
                k=i[0:5]
                if k==chat:
                    ff=User+"/"+i
                    file = codecs.open(ff, 'r', "utf-8")
                    print(file.read())
        else:
            ftp.quit()

        m=len(caluculu)
        ftp = ftplib.FTP(timeout=30)
        ftp.connect(Host, Port)
        ftp.login(User, Pass)
        ftp.cwd(User)
        if m>0:
            isDownloadSuccess = downloadFun(ftp,path,User,caluculu,remotefol)
            for i in data:
                if i[0]=='x':
                    reply=i[1:6]
                    ff=User+"/"+i
                    file1=open(ff,"r+")
                    str1=file1.readline()
                    
                    val=eval(str1)
                    lines=str(val)
                    inpfile='mess.txt'
                    with open(inpfile, 'w') as f:
                        f.writelines(lines)
                    path=inpfile
                    
                    ftp = ftplib.FTP(timeout=30)
                    ftp.connect(Host, Port)
                    ftp.login(User, Pass)
                    ftp.cwd(reply)
                    
                    global key
                    File=User+str(key)+".txt"
                    key=key+1
                    successupload = uploadfunction(ftp,path,File,  remotefol)
                    

                    


        sleep(1)
            

   



Host = '192.168.142.69'
Port = 2211
print("user name:")
User = input()
print("password:")
Pass = input()
remotefol = "."
print("welcome to ftp server")
print("user guide")
print("select chat:")
print("followed by ")
print("enter message: or press change for changing chat")
print("to caluculate write cal or you can simply chat:")
key=1
chat=input()
event=Event()

t1=threading.Thread(target=readmess,args=(event,User,Pass,Host,Port,chat,))
t1.start()
while(True):
    remotefol = "."
    per=chat
    lines = input()
    while lines=="change":
        print("select chat")
        chat=input()
        event.set()

        t1=threading.Thread(target=readmess,args=(event,User,Pass,Host,Port,chat,))
        t1.start()
        print("enter text or write change command for changining chat:")
        lines=input()
    
    mode=input()
        


    inpfile='mess.txt'
    with open(inpfile, 'w') as f:
        f.writelines(lines)
    path=inpfile

    ftp = ftplib.FTP(timeout=300)
    ftp.connect(Host, Port)
    ftp.login(User, Pass)
    ftp.cwd(chat)
    remotefolx=remotefol+"/"+per
    
    File=User+str(key)+".txt"
    if mode == "cal":
        File="x"+File
    key=key+1
    successupload = uploadfunction(ftp,path,File,  remotefolx)



