from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pyftpdlib.authorizers import DummyAuthorizer
import os, socket
ip= '192.168.10.69'
path ='/Users/soumadeepacharya/Desktop/ias4/ftpserver'
os.chdir(path)
addr= (ip, 2211)
name=DummyAuthorizer()
name.add_user('user','1234','/Users/soumadeepacharya/Desktop/ias4/ftpserver',perm='elradfmw')

handler=FTPHandler
handler.authorizer=name
server=FTPServer(addr,handler)
server.serve_forever()
