import ftplib
import sys
import os
import webbrowser
import codecs
import threading 
from time import sleep
from threading import Event






def downloadFun(ftp,fpath,user, Files, remoteWorkingDirectory,name):
    i=0
    Code='989'
    while i<len(Files):
        singfile = Files[i]
        i=i+1
       
        # fpath=os.path.join(fpath, user)
       
        path = os.path.join(fpath,singfile)
        # print(path)
        # print("downloading ....... {0}".format(singfile))
        # print(path,singfile)
        # singfile=os.path.join(user,singfile)
       
        with open(path, "wb") as file:
            Code = ftp.retrbinary("RETR " + singfile, file.write)
        ftp.delete(singfile)
       
    if Code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def uploadfunction(ftp,Path,File, workingDir,name): 
    code='999'
    with open(Path, "rb") as file:
        code = ftp.storbinary(f"STOR {File}", file, blocksize=1024*1024)
    
    if code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False
def mulfun(fileadd,subser):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(subser)
    User=subser
    path =User
    remotefol='.'
    global ser
    remotefolx=remotefol+"/"+ser

    filex=[]
    filex.append(fileadd)
    isDownloadSuccess = downloadFun(ftp,path,User,filex,remotefolx,name)
    lis=list(fileadd.split("&"))
    fileadd=User+"/"+fileadd

    reply=lis[0]
    file1=open(fileadd,"r+")
    str1=file1.readline()
    lt=list(str1.split(" "))
    
    val=float(lt[1])*float(lt[2])
    lines=str(val)
    global key
    
    inpfile=str(key)+'mess.txt'
    inpfile=User+"/"+inpfile
    key=key+1
    with open(inpfile, 'w') as f:
        f.writelines(lines)
    path=inpfile
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(reply)
    
    File="result"+str(key)+".txt"
    key=key+1
    uploadfunction(ftp,path,File,  remotefol,name)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd("server0")
    File=reply+"record"+".txt"
    uploadfunction(ftp,path,File,  remotefol,name)
    os.remove(path)

def subfun(fileadd,subser):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(subser)
    User=subser
    path =User
    remotefol='.'
    global ser
    remotefolx=remotefol+"/"+ser

    filex=[]
    filex.append(fileadd)
    isDownloadSuccess = downloadFun(ftp,path,User,filex,remotefolx,name)
    lis=list(fileadd.split("&"))
    fileadd=User+"/"+fileadd


    reply=lis[0]
    file1=open(fileadd,"r+")
    str1=file1.readline()
    lt=list(str1.split(" "))
    
    val=float(lt[1])-float(lt[2])
    lines=str(val)
    global key
    
    inpfile=str(key)+'mess.txt'
    inpfile=User+"/"+inpfile
    key=key+1
    with open(inpfile, 'w') as f:
        f.writelines(lines)
    path=inpfile
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(reply)
    
    File="result"+str(key)+".txt"
    key=key+1
    uploadfunction(ftp,path,File,  remotefol,name)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd("server0")
    File=reply+"record"+".txt"
    uploadfunction(ftp,path,File,  remotefol,name)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd("server0")
    File=reply+"record"+".txt"
    uploadfunction(ftp,path,File,  remotefol,name)
    os.remove(path)

def addfun(fileadd,subser):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(subser)
    User=subser
    path =User
    remotefol='.'
    global ser
    remotefolx=remotefol+"/"+ser

    filex=[]
    filex.append(fileadd)
    isDownloadSuccess = downloadFun(ftp,path,User,filex,remotefolx,name)
    lis=list(fileadd.split("&"))
    fileadd=User+"/"+fileadd

    reply=lis[0]
    file1=open(fileadd,"r+")
    str1=file1.readline()
    lt=list(str1.split(" "))
    
    val=float(lt[1])+float(lt[2])
    lines=str(val)
    global key
    
    inpfile=str(key)+'mess.txt'
    key=key+1
    inpfile=User+"/"+inpfile
    with open(inpfile, 'w') as f:
        f.writelines(lines)
    path=inpfile
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(reply)
    
    File="result"+str(key)+".txt"
    key=key+1
    uploadfunction(ftp,path,File,  remotefol,name)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd("server0")
    File=reply+"record"+".txt"
    uploadfunction(ftp,path,File,  remotefol,name)
    os.remove(path)

def incfun(fileadd,subser):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(subser)
    User=subser
    path =User
    remotefol='.'
    global ser
    remotefolx=remotefol+"/"+ser

    filex=[]
    filex.append(fileadd)
    isDownloadSuccess = downloadFun(ftp,path,User,filex,remotefolx,name)
    lis=list(fileadd.split("&"))
    fileadd=User+"/"+fileadd

    reply=lis[0]
    file1=open(fileadd,"r+")
    str1=file1.readline()
    lt=list(str1.split(" "))
    
    val=float(lt[1])+float(lt[2])
    lines=str(val)
    global key
    
    inpfile=str(key)+'mess.txt'
    key=key+1
    inpfile=User+"/"+inpfile
    with open(inpfile, 'w') as f:
        f.writelines(lines)
    path=inpfile
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(reply)
    
    File="result"+str(key)+".txt"
    key=key+1
    uploadfunction(ftp,path,File,  remotefol,name)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd("server0")
    File=reply+"record"+".txt"
    uploadfunction(ftp,path,File,  remotefol,name)
    os.remove(path)



def calacala():
    while True:
        f5=open("address.txt",'r')
        lines=f5.readlines()
        for i in lines:
            lis=list(i.split(" "))
            len1=len(lis)
            str0=lis[0]
            str1=lis[1]
            if str0=="add":
                ftp = ftplib.FTP(timeout=30)
                ftp.connect(Host, Port)
                ftp.login("user", Pass)
                ftp.cwd(str1)
                datax = ftp.nlst()
                ftp.quit()
                for j in datax:
                    t1=threading.Thread(target=addfun,args=(j,str1))
                    t1.start()
                

            elif str0=="sub":
                ftp = ftplib.FTP(timeout=30)
                ftp.connect(Host, Port)
                ftp.login("user", Pass)
                ftp.cwd(str1)
                datax = ftp.nlst()
                ftp.quit()
                for j in datax:
                    t1=threading.Thread(target=subfun,args=(j,str1))
                    t1.start()
            elif str0=="mul":
                ftp = ftplib.FTP(timeout=30)
                ftp.connect(Host, Port)
                ftp.login("user", Pass)
                ftp.cwd(str1)
                datax = ftp.nlst()
                ftp.quit()
                for j in datax:
                    t1=threading.Thread(target=mulfun,args=(j,str1))
                    t1.start()
            elif str0=="inc":
                ftp = ftplib.FTP(timeout=30)
                ftp.connect(Host, Port)
                ftp.login("user", Pass)
                ftp.cwd(str1)
                datax = ftp.nlst()
                ftp.quit()
                for j in datax:
                    t1=threading.Thread(target=incfun,args=(j,str1))
                    t1.start()
        sleep(0.5)



ser="server0"
Host = '192.168.10.69'
Port = 2211
User=ser
Pass="1234"
key=1


with open('address.txt', 'a') as fp:
    pass
addfile="address.txt"
fx=open(addfile,'r')
lines=fx.readlines()
dircheck={}
dircheck[ser]=0
if len(sys.argv)>3:
    dircheck[sys.argv[3]]=0
for i in lines:
    ls1=list(i.split(" "))
    dircheck[str(ls1[1])]=1


ftp = ftplib.FTP(timeout=30)
ftp.connect(Host, Port)
ftp.login("user", Pass)
name="user"
if dircheck[ser]==0:
    ftp.mkd(ser)
ftp.quit()
if dircheck[ser]==0:
    lines="start"+" "+ser+" "
    addfile='address.txt'
    with open(addfile, 'a') as f:
        f.writelines(lines)
        f.writelines("\n")
    f.close()
n1dir="./"+ser
if not os.path.exists(n1dir):
    os.mkdir(n1dir)
if len(sys.argv)>3:
    if sys.argv[1]=='newserver':
        if dircheck[sys.argv[3]]==0:
            lines=sys.argv[2]+" "+sys.argv[3]+" "
            addfile="address.txt"
            with open(addfile, 'a') as f:
                f.writelines(lines)
                f.writelines("\n")
            f.close()
        
        ftp = ftplib.FTP(timeout=30)
        ftp.connect(Host, Port)
        ftp.login("user", Pass)
        
        if dircheck[sys.argv[3]]==0:
            ftp.mkd(sys.argv[3])
        ftp.quit()
        n1dir="./"+sys.argv[3]
        if not os.path.exists(n1dir):
            os.mkdir(n1dir)
    quit()

print("hello world")

print("::::::main serever started::💀💀::")

t1=threading.Thread(target= calacala,args=())
t1.start()
while True:
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login("user", Pass)
    ftp.cwd(User)
    remotefol = "."
    data = ftp.nlst()
    connrequest=[]
    for i in data:
        k=i[0:3]
        # print(k)
        if k=='req':
            connrequest.append(i)
        
        
    ftp.quit()
    connsize=len(connrequest)
    if connsize>0:
        
        ftp = ftplib.FTP(timeout=30)
        ftp.connect(Host, Port)
        ftp.login("user", Pass)
        ftp.cwd(ser)
        path =User
        isDownloadSuccess = downloadFun(ftp,path,User,connrequest,remotefol,name)
        for i in connrequest:
            j=User+"/"+i
            filex=open(j,"r")
            line1=filex.readline()
            filex.close()
            lsz=line1.split("&")[0]

            ftp = ftplib.FTP(timeout=30)
            ftp.connect(Host, Port)
            ftp.login("user", Pass)
            ftp.cwd(lsz)
            path="address.txt"
            
            File="addreply"+str(key)+".txt"
            key=key+1
            uploadfunction(ftp,path,File,  remotefol,name)
            # os.remove(path)
        


    
    sleep(0.5)





