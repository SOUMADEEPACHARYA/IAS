at first you have to run ftpserver and have to set the path
you have to run server and add server then you can run client.py
for adding server you have to give command like server.py newserver add s1


