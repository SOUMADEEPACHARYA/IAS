import ftplib
import os
import webbrowser
import codecs
import threading 
from time import sleep
from threading import Event

def downloadFun(ftp,fpath,user, Files, remoteWorkingDirectory,name):
    i=0
    Code='989'
    while i<len(Files):
        singfile = Files[i]
        i=i+1
       
        # fpath=os.path.join(fpath, user)
       
        path = os.path.join(fpath,singfile)
        # print(path)
        # print("downloading ....... {0}".format(singfile))
        # print(path,singfile)
        # singfile=os.path.join(user,singfile)
       
        with open(path, "wb") as file:
            Code = ftp.retrbinary("RETR " + singfile, file.write)
        ftp.delete(singfile)
       
    if Code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def uploadfunction(ftp,Path,File, workingDir,name): 
    code='999'
    with open(Path, "rb") as file:
        code = ftp.storbinary(f"STOR {File}", file, blocksize=1024*1024)
    
    if code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def readmess(User,Pass,Host,Port,name):
    m=0
    while True:
        ftp = ftplib.FTP(timeout=3000)
        ftp.connect(Host, Port)
        ftp.login(name, Pass)
        ftp.cwd(User)
        
        
        remotefol = "."
        path=User
        data = ftp.nlst()
        
        caluculu=[]
        for i in data:
            k=i[0:6]
            # print(k)
            if k=='result':
                caluculu.append(i)
        
        n=len(caluculu)
        
        if n>0:
            isDownloadSuccess = downloadFun(ftp,path,User,caluculu,remotefol,name)
            for i in data:
                k=i[0:6]
                if k=='result':
                    ff=User+"/"+i
                    file = codecs.open(ff, 'r', "utf-8")
                    print(file.read())
        else:
            ftp.quit()

    
        sleep(0.5)







Host = '192.168.10.69'
Port = 2211
print("user name:")
User=input()
# ndir="/Users/soumadeepacharya/Desktop/ias4/ftpserver/"+User
# if not os.path.exists(ndir):
#     os.mkdir(ndir)
Pass = '1234'
ftp = ftplib.FTP(timeout=30)
ftp.connect(Host, Port)
ftp.login("user", Pass)
ftp.mkd(User)
ftp.quit()
n1dir="./"+User
if not os.path.exists(n1dir):
    os.mkdir(n1dir)
name = 'user'

remotefol = "."

ftp = ftplib.FTP(timeout=300)
ftp.connect(Host, Port)
ftp.login(name, Pass)
ftp.cwd("server0")
key=1
inpfile= "req"+str(key)+'mess.txt'
File=inpfile
key=key+1
lines=User+"&"
inpfile=User+"/"+inpfile
with open(inpfile, 'w') as f:
    f.writelines(lines)
path=inpfile

uploadfunction(ftp,path,File,  remotefol,name)
os.remove(path)
ftp = ftplib.FTP(timeout=300)
ftp.connect(Host, Port)
ftp.login(name, Pass)
ftp.cwd(User)
while(True):
    data=ftp.nlst()
    if len(data)>0:
        break
    else:
        sleep(0.5)
ftp.quit()
ftp = ftplib.FTP(timeout=300)
ftp.connect(Host, Port)
ftp.login(name, Pass)
ftp.cwd(User)
recieveadd=[]
for i in data:
    k=i[0:8]
    if k=="addreply":
        recieveadd.append(i)
path=User

isDownloadSuccess = downloadFun(ftp,path,User,recieveadd,remotefol,name)
mp={}
for i in data:
    k=i[0:8]
    if k=="addreply":
        ff=User+"/"+i
        file1 = open(ff, 'r')
        Lines = file1.readlines()
        for l in Lines:
            ls=l.split()
            mp[ls[0]]=ls[1]

for i in mp:
    print("for ",i,",the server is",mp[i])
    
t1=threading.Thread(target=readmess,args=(User,Pass,Host,Port,name))
t1.start()
while(True):
    
    inp=input()
    if inp=="lookup":
        for i in mp:
            print("for ",i,",the server is",mp[i])
        continue
    inp=inp[0:3]
    if inp not in mp.keys():
        print("server is not available")
    elif inp=="add":
        remotefolx=remotefol+"/"+User
        print("give command like add x y")
        linex=input()
        writingfile=User+"&"+str(key)+".txt"
        File=writingfile
        writingfile=User+"/"+writingfile
        key=key+1
        with open(writingfile, 'w') as f:
            f.writelines(linex)
        path=writingfile
        ftp = ftplib.FTP(timeout=300)
        ftp.connect(Host, Port)
        ftp.login(name, Pass)
       
        serx=mp["add"]
        ftp.cwd(serx)
        
        
        uploadfunction(ftp,path,File,  remotefolx,name)
        os.remove(path)
    elif inp=="mul":
        remotefolx=remotefol+"/"+User
        print("give command like mul x y")
        linex=input()
        writingfile=User+"&"+str(key)+".txt"
        File=writingfile
        writingfile=User+"/"+writingfile
        key=key+1
        with open(writingfile, 'w') as f:
            f.writelines(linex)
        path=writingfile
        ftp = ftplib.FTP(timeout=300)
        ftp.connect(Host, Port)
        ftp.login(name, Pass)
    
        serx=mp["mul"]
        ftp.cwd(serx)
        
        
        uploadfunction(ftp,path,File,  remotefolx,name)
        os.remove(path)
    elif inp=="sub":
        remotefolx=remotefol+"/"+User
        print("give command like sub  x y")
        linex=input()
        writingfile=User+"&"+str(key)+".txt"
        File=writingfile
        writingfile=User+"/"+writingfile
        key=key+1
        with open(writingfile, 'w') as f:
            f.writelines(linex)
        path=writingfile
        ftp = ftplib.FTP(timeout=300)
        ftp.connect(Host, Port)
        ftp.login(name, Pass)
    
        serx=mp["sub"]
        ftp.cwd(serx)
        
        uploadfunction(ftp,path,File,  remotefolx,name)
        os.remove(path)
    elif inp=="inc":
        ftp = ftplib.FTP(timeout=300)
        ftp.connect(Host, Port)
        ftp.login(name, Pass)
        ftp.cwd("server0")
        data=ftp.nlst()
        record=[]
        ss=User+"record.txt"
        for i in data:
            if i==ss:
                record.append(i)
        nsize=len(record)
        if nsize>0:
            path=User

            isDownloadSuccess = downloadFun(ftp,path,User,record,remotefol,name)
            fileadd=path+"/"+record[0]
            file1=open(fileadd,"r+")
            str1=file1.readline()
            lt=list(str1.split(" "))
            xval=float(lt[0])
            linex="inc "+str(xval)+" "+"1"


            writingfile=User+"&"+str(key)+".txt"
            File=writingfile
            writingfile=User+"/"+writingfile
            key=key+1
            with open(writingfile, 'w') as f:
                f.writelines(linex)
            path=writingfile
            ftp = ftplib.FTP(timeout=300)
            ftp.connect(Host, Port)
            ftp.login(name, Pass)
        
            serx=mp["inc"]
            ftp.cwd(serx)
            
            uploadfunction(ftp,path,File,  remotefolx,name)
            os.remove(path)


        else:
            print("no previous record found ")
        
            


