from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pyftpdlib.authorizers import DummyAuthorizer
import os, socket
ip= '127.0.0.1'
path ='/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk'
os.chdir(path)
addr= (ip, 2211)
name=DummyAuthorizer()
name.add_user('user1','1234','/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk',perm='elradfmw')
name.add_user('user2','1234','/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk',perm='elradfmw')
name.add_user('user3','1234','/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk',perm='elradfmw')
name.add_user('user4','1234','/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk',perm='elradfmw')
name.add_user('user5','1234','/Users/soumadeepacharya/Documents/FTPWEBSERVER/serverdisk',perm='elradfmw')

handler=FTPHandler
handler.authorizer=name
server=FTPServer(addr,handler)
server.serve_forever()
