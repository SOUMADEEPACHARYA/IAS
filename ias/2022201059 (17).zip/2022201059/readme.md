first set path in server
then there are 5 user
user1
user2
user3
user4
user5
and password 1234
