import ftplib
import os
import webbrowser
import codecs

def downloadFun(ftp,fpath,user, Files, remoteWorkingDirectory):
    i=0
    while i<len(Files):
        singfile = Files[i]
        i=i+1
        path = os.path.join(fpath, singfile)
       
        with open(path, "wb") as file:
            Code = ftp.retrbinary("RETR " + singfile, file.write)
    if Code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def uploadfunction(ftp,Path,File, workingDir): 
   
    with open(Path, "rb") as file:
        code = ftp.storbinary(f"STOR {File}", file, blocksize=1024*1024)
    
    if code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False



Host = '127.0.0.1'
Port = 2211
print("user name:")
User = input()
print("password:")
Pass = input()
remotefol = "."

print("welcome to ftp server")

while(True):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login(User, Pass)
    ftp.cwd(User)

    path=User
    x='index.txt'
    htmlfile=[]
    htmlfile.append(x)



    isDownloadSuccess = downloadFun(ftp,path,User,htmlfile,remotefol)
    ff=User+"/"+x
    file = codecs.open(ff, 'r', "utf-8")
    print(file.read())
    print("press write for send message else read for new message")
    str=input()
    if str=="read":
        continue
    elif str=="WHO AM I":
        print(User)
    else:
        print("which person: ")
        per=input()
        print("enter message:")
        lines = input()
        lines=lines+"( from "+User+")"
        inpfile=User+"/"+'index.txt'
        with open(inpfile, 'w') as f:
            f.writelines(lines)
        path=inpfile

        ftp = ftplib.FTP(timeout=30)
        ftp.connect(Host, Port)
        ftp.login(User, Pass)
        ftp.cwd(per)
        _, File = os.path.split(path)
        remotefolx=remotefol
        successupload = uploadfunction(ftp,path,File,  remotefolx)

   