import sys
import json
FILE_NAME = 'rpc_server.py'
SERVER = '127.0.0.1'
PORT = 12000



def importing():
    libdetail = ""
    import_lib = ["from server_procedures import *", "import socket","import threading"]
    i=0
    while i <len(import_lib):
        str1=import_lib[i]
        libdetail = libdetail+f"{str1}"+'\n'
        i=i+1
    libdetail = libdetail+'\n'+'\n'+'\n'+'\n'
    return libdetail


def connection():
    netddetail=""
    name=["serverBuffer","SERVER","PORT","ADDRESS"]
    val=["600","socket.gethostbyname((socket.gethostname()))",12000, "(SERVER, PORT)"]
    i=0
    n=len(val)
    while i<n:
        netddetail =netddetail+f"{name[i]} = {val[i]}"+'\n'
        i=i+1
   
    netddetail=netddetail+'\n'+'\n'+'\n'
    return netddetail


def rpc():
    x = '''def handler(function_info,client_sock):
    func_dict = eval(function_info)
    function_call = f"{list(func_dict.keys())[0]}(*{list(func_dict.values())[0]})"
    client_sock.send(str(eval(function_call)).encode())
    client_sock.close()'''
    x=x+'\n'+'\n'+'\n'
    return x


def connection_builder():
    x = '''def start():
    print("RPC SERVER has been started")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except KeyboardInterrupt:
        print("SOCKET CREATION FAIL")
        s.close()
        exit()
    try:
        s.bind(ADDRESS)
    except KeyboardInterrupt:
        print("SOCKET BIND FAIL")
        s.close()
        exit()

    
    try:
        s.listen(6)
        while True:
            client_sock, addr = s.accept()
            mess=client_sock.recv(serverBuffer).decode()
            new_thread = threading.Thread(target=handler, args=(mess,client_sock))
            new_thread.start()
    except KeyboardInterrupt:
        print("RPC SERVER is down now")
        s.close()
        exit()'''+'\n'+'\n'+"start()"+'\n'+'\n'
    return x


if len(sys.argv) == 2:
    f = open(FILE_NAME, "w")
    f.write(importing())
    f.write(connection())
    f.write(rpc())
    f.write(connection_builder())
    f.close()