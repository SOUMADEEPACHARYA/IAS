
import sys
import json
FILE_NAME = 'rpc_client.py'
SERVER = '127.0.0.1'
PORT = 12000



def importing():
    libdetail = ""
    import_lib = ["import socket"]
    i=0
    while i <len(import_lib):
        str1=import_lib[i]
        libdetail = libdetail+f"{str1}"+'\n'
        i=i+1
    libdetail = libdetail+'\n'+'\n'+'\n'+'\n'
    return libdetail


def connectiongStablish():
    netddetail=""
    name=["buffer","SERVER","PORT","ADDRESS"]
    val=["600","socket.gethostbyname((socket.gethostname()))",12000, "(SERVER, PORT)"]
    i=0
    n=len(val)
    while i<n:
        netddetail =netddetail+f"{name[i]} = {val[i]}"+'\n'
        i=i+1
   
    netddetail=netddetail+'\n'+'\n'+'\n'
    return netddetail






def rpc():
    x = '''def rpc_connector(func_name, param_list):
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	except KeyboardInterrupt:
		print("SOCKET CREATION FAIL")
		s.close()
		exit()
	try:
		s.connect(ADDRESS)
	except KeyboardInterrupt:
		print("connection failed")
		s.close()
		exit()

	try:
		s.send(str({func_name: param_list}).encode())
	except KeyboardInterrupt:
		print("sending error")
		s.close()
		exit()
	retv = s.recv(buffer).decode()
	return retv
'''
    x=x+'\n'+'\n'+'\n'
    return x

def fun(name,par,ret,rettype):
    x=f'''def {name}({par}):
	return {rettype}(rpc_connector('{name}',[{ret}]))'''
    x=x+"\n"+"\n"
    return x


def start(filex):
    f1 = open(filex)
    data = json.load(f1)
    f1.close()
    f = open(FILE_NAME, "w")
    f.write(importing())
    f.write(connectiongStablish())
    f.write(rpc())
    datax=data['remote_procedures']
    for p in datax:
        # print(procedure)
        name = p["procedure_name"]
        par = p["parameters"]
        rettype = p["return_type"]
        parline=""
        ret=""
        i=0
        while i < len(par):
            
            u=par[i]["parameter_name"]
            v=par[i]["data_type"]
            parline=parline+f"{u}:{v}"
            ret=ret+f"{u}"
            if(i<len(par)-1):
                parline+=","
                ret+=","
            i=i+1
        function_string = fun(name,parline,ret,rettype)

        f.write(function_string)
    f.close()


if len(sys.argv) == 2:
    start(sys.argv[1])
