from rpc_client import *

print(foo(123))
print(bar(11, "aaa"))
# print(zoo()
# foo("Helo")
print("rate:",random_rating())
print(foo(123))
print(bar(12, "aaa"))
# print(zoo()
# foo("Helo")
print("rate:",random_rating())