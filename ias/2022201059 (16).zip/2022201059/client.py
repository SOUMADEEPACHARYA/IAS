import ftplib
import os
import webbrowser
import codecs
def listfile(ftp,remoteWorkingDirectory):
    filelist = []
    filelist = ftp.nlst()
    ftp.quit()
    return filelist


def downloadFun(ftp,fpath, Files, remoteWorkingDirectory):
    i=0
    while i<len(Files):
        singfile = Files[i]
        i=i+1
        path = os.path.join(fpath, singfile)
        print("downloading ....... {0}".format(singfile))
        print(path,singfile)
        with open(path, "wb") as file:
            Code = ftp.retrbinary("RETR " + singfile, file.write)
    if Code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False


def uploadfunction(ftp,Path,File, workingDir): 
   
    with open(Path, "rb") as file:
        code = ftp.storbinary(f"STOR {File}", file, blocksize=1024*1024)
    
    if code.startswith('226'):
        ftp.quit()
        return True
    else:
        ftp.quit()
        return False



Host = '127.0.0.1'
Port = 2211
User = 'bilu'
Pass = '1234'
remotefol = "."
ftp = ftplib.FTP(timeout=30)
ftp.connect(Host, Port)
ftp.login(User, Pass)
path=""
x='index.html'
htmlfile=[]
htmlfile.append(x)

isDownloadSuccess = downloadFun(ftp,path,htmlfile,remotefol)
file = codecs.open("index.html", 'r', "utf-8")
print(file.read())
print("welcome to ftp server")

while(True):
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(Host, Port)
    ftp.login(User, Pass)
    url = input()
    split_url=url.split('/')
    n=len(split_url)
    filex=split_url[n-1]

    inp=split_url[0]
    print(filex,inp)

    if inp =='PUT':
        # print("what file you you want to upload")
        path= filex
        _, File = os.path.split(filex)

        successupload = uploadfunction(ftp,path,File,  remotefol)

        print("upload  file status = {0}".format(successupload))
    elif inp =='GET':
        # print("hello, what file you want to download")
        Path = ""
        remoteFile=[]
        # x=input()
        remoteFile.append(filex)
        print(remoteFile)
        isDownloadSuccess = downloadFun(ftp,Path,remoteFile,  remotefol)

        print("download status = {0}".format(isDownloadSuccess))
    elif inp=='LIST':
        fnames = listfile(ftp, ".")
        print(fnames)






