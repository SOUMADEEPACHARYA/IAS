from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pyftpdlib.authorizers import DummyAuthorizer
import os, socket
ip= socket.gethostbyname(socket.gethostname())
path ='/Users/soumadeepacharya/Downloads/2022201059-23/serverdisk'
os.chdir(path)
addr= (ip, 2211)
name=DummyAuthorizer()
name.add_user('bilu','1234','/Users/soumadeepacharya/Downloads/2022201059-23/serverdisk',perm='elradfmw')
name.add_anonymous('/Users/soumadeepacharya/Downloads/2022201059-23/serverdisk')
handler=FTPHandler
handler.authorizer=name
server=FTPServer(addr,handler)
server.serve_forever()
